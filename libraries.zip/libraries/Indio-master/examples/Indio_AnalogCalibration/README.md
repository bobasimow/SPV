# Sketch to generate the Analog Calibration data for Industruino IND.I/O

See instructions in the sketch and blog post here https://industruino.com/blog/our-news-1/post/ind-i-o-analog-calibration-18


Your calibration data will appear in the Serial Monitor and you will have to update your Indio.cpp library file.


